package com.example.it_vyzovcitek.users;

public class User {
    String username, profileImage;


    public User(String username, String profileImage) {
        this.username = username;
        this.profileImage = profileImage;
    }
}
